package com.maestros.arogyalabside;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ChangeMobNoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_mob_no);
    }
}