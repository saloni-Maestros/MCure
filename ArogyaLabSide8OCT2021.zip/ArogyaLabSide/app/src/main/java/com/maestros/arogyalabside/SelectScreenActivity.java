package com.maestros.arogyalabside;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.button.MaterialButton;

public class SelectScreenActivity extends AppCompatActivity {
    MaterialButton materialbuttonnext;
    RadioGroup radiogroup_doctor,radiogroup_lab;
    RadioButton radio_btn_doctor,radio_btn_lab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_screen);

        radio_btn_doctor=findViewById(R.id.radio_btn_doctor);
        radiogroup_doctor=findViewById(R.id.radiogroup_doctor);
        radiogroup_lab=findViewById(R.id.radiogroup_lab);
        radio_btn_lab=findViewById(R.id.radio_btn_lab);
        materialbuttonnext = findViewById(R.id.materialbuttonnext);
        materialbuttonnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             startActivity(new Intent(SelectScreenActivity.this,LoginActivity.class));
            }
        });
        radio_btn_doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               // radio_btn_doctor.setVisibility(view.getVisibility());
                radio_btn_doctor.setVisibility(View.VISIBLE);
                radiogroup_doctor.setVisibility(View.VISIBLE);
                //radiogroup_lab.setVisibility(View.GONE);
                radio_btn_lab.setVisibility(View.GONE);
            }
        });

        radio_btn_lab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                radiogroup_lab.setVisibility(View.VISIBLE);
                radio_btn_lab.setVisibility(View.VISIBLE);
                radio_btn_doctor.setVisibility(View.GONE);
               // radiogroup_doctor.setVisibility(View.GONE);

            }
        });
    }
}