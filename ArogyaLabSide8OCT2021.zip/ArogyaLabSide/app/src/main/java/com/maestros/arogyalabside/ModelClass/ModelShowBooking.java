package com.maestros.arogyalabside.ModelClass;

public class ModelShowBooking {

    public String ShowId;
    public String ShowPic;
    public String ShowUserName;
    public String ShowAge;
    public String ShowDatetime;
    public String ShowHistory;
    public String ShowStatus;
    public String ShowPending;
    public String ShowPath;


    public String getShowId() {
        return ShowId;
    }

    public void setShowId(String showId) {
        ShowId = showId;
    }


    public String getShowPath() {
        return ShowPath;
    }

    public void setShowPath(String showPath) {
        ShowPath = showPath;
    }

    public String getShowPic() {
        return ShowPic;
    }

    public void setShowPic(String showPic) {
        ShowPic = showPic;
    }

    public String getShowUserName() {
        return ShowUserName;
    }

    public void setShowUserName(String showUserName) {
        ShowUserName = showUserName;
    }

    public String getShowAge() {
        return ShowAge;
    }

    public void setShowAge(String showAge) {
        ShowAge = showAge;
    }

    public String getShowDatetime() {
        return ShowDatetime;
    }

    public void setShowDatetime(String showDatetime) {
        ShowDatetime = showDatetime;
    }

    public String getShowHistory() {
        return ShowHistory;
    }

    public void setShowHistory(String showHistory) {
        ShowHistory = showHistory;
    }

    public String getShowStatus() {
        return ShowStatus;
    }

    public void setShowStatus(String showStatus) {
        ShowStatus = showStatus;
    }

    public String getShowPending() {
        return ShowPending;
    }

    public void setShowPending(String showPending) {
        ShowPending = showPending;
    }
}
