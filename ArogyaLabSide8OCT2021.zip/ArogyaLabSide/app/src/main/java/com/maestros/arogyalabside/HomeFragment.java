package com.maestros.arogyalabside;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.google.android.material.button.MaterialButton;
import com.maestros.arogyalabside.Adapter.ShowBookingAdapter;
import com.maestros.arogyalabside.ModelClass.ModelShowBooking;
import com.maestros.arogyalabside.others.API;
import com.maestros.arogyalabside.others.APPCONSTANT;
import com.maestros.arogyalabside.others.SharedHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class HomeFragment extends Fragment {
    LinearLayout ll_solvecxse;
    LinearLayout ll_my_case;
    RecyclerView rev_booking;
   ImageView img_menu;
   MaterialButton NewCasebtn,SolveCaseBtn;

    RecyclerView recyclerview;
    ShowBookingAdapter bookingAdapter;
    ArrayList<ModelShowBooking> ModelShowBookings;
    String UserId ="";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);

        img_menu=view.findViewById(R.id.img_menu);
        rev_booking=view.findViewById(R.id.rev_booking);

       // ll_solvecxse= view.findViewById(R.id.ll_solvecxse);       // in fragment write view before find id
       // ll_my_case = view.findViewById(R.id.ll_my_case);
        NewCasebtn = view.findViewById(R.id.NewCasebtn);
        SolveCaseBtn=view.findViewById(R.id.SolveCaseBtn);

        UserId = SharedHelper.getKey(getActivity(), APPCONSTANT.USERID);
        Log.e("userid", UserId);

           img_menu.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                 NavActivity.drawer_layout.openDrawer(Gravity.START);
            }
        });

       NewCasebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


               // ll_my_case.setVisibility(View.GONE);

               // ll_solvecxse.setVisibility(View.VISIBLE);

                NewCasebtn.setBackgroundColor(getResources().getColor(R.color.purple_200));
                SolveCaseBtn.setBackgroundColor(getResources().getColor(R.color.white));

                //startActivity(new Intent(getActivity(), HomeScreen1MainActivity.class));
            }
        });



       /* SolveCaseBtn = view.findViewById(R.id.SolveCaseBtn);
        SolveCaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_my_case.setVisibility(View.VISIBLE);
                //ll_solvecxse.setVisibility(View.GONE);
                SolveCaseBtn.setBackgroundColor(getResources().getColor(R.color.purple_200));
                NewCasebtn.setBackgroundColor(getResources().getColor(R.color.white));
            }
        });
*/

    /*    ll_my_case.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/
       /* ll_solvecxse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/

        showBooking();

        return view;
    }

    private void showBooking() {
        Log.e("UserId", UserId);
        AndroidNetworking.post(API.show_doctor_booking)
                .addBodyParameter("user_id",UserId)
                .setTag("ShowBooking")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                        ModelShowBookings = new ArrayList<>();

                        Log.e("fyytrfty", "onResponse: "+response);

                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                jsonObject.getString("id");
                                jsonObject.getString("time");

                                JSONArray jsonArray1 = new JSONArray(jsonObject.getString("user_details"));
                                for (int j = 0; j < jsonArray1.length(); j++) {

                                    Log.e("fyyt", "onResponse: "+response);

                                    JSONObject jsonObject1 = jsonArray1.getJSONObject(j);
                                    ModelShowBooking showBooking = new ModelShowBooking();
                                    showBooking.setShowId(jsonObject1.getString("id"));
                                    showBooking.setShowPic(jsonObject1.getString("image"));
                                    showBooking.setShowPath(jsonObject1.getString("path"));
                                   showBooking.setShowDatetime(jsonObject.getString("dates")+jsonObject.getString("time"));
                                    showBooking.setShowStatus(jsonObject1.getString("status"));
                                    showBooking.setShowUserName(jsonObject1.getString("name"));
                                    showBooking.setShowAge(jsonObject1.getString("age"));

                                    ModelShowBookings.add(showBooking);


                                }


                            }


                            bookingAdapter = new ShowBookingAdapter(ModelShowBookings, getActivity());
                            rev_booking.setHasFixedSize(true);
                            rev_booking.setLayoutManager(new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL,false));
                            rev_booking.setAdapter(bookingAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("rtyrttgrgt", "onResponse: " +e.getMessage());
                        }


                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("fcdsdsfcsd", "onError: " +anError.getMessage());

                    }
                });



    }


}