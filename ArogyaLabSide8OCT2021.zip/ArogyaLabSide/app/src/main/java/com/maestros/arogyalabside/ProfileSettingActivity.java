package com.maestros.arogyalabside;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.material.button.MaterialButton;
import com.maestros.arogyalabside.others.API;
import com.maestros.arogyalabside.others.APPCONSTANT;
import com.maestros.arogyalabside.others.SharedHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProfileSettingActivity extends AppCompatActivity {
  MaterialButton materialbuttonsave;
  String USERID = "";
  EditText ev_drname;
  EditText Ev_Regno;
  Spinner sp_mbbs;
  ArrayList<String>arr_specID;
  ArrayList<String>arr_specName;
  ImageView imgarrow_profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_setting);
        ev_drname = findViewById(R.id.ev_drname);
        Ev_Regno = findViewById(R.id.Ev_Regno);
        materialbuttonsave = findViewById(R.id.materialbuttonsave);
        sp_mbbs = findViewById(R.id.sp_mbbs);
        imgarrow_profile=findViewById(R.id.imgarrow_profile);
        imgarrow_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        materialbuttonsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ev_drname.getText().toString().trim().isEmpty()){
                    Toast.makeText(ProfileSettingActivity.this, "Please enter Dr.Name ", Toast.LENGTH_SHORT).show();
                } else if(Ev_Regno.getText().toString().trim().isEmpty()){
                    Toast.makeText(ProfileSettingActivity.this, "Please enter Reg Number", Toast.LENGTH_SHORT).show();
                }
                updateProfile();

            }
        });

        USERID= SharedHelper.getKey(ProfileSettingActivity.this,APPCONSTANT.USERID);
        Log.e("gdfgdf",USERID );
        shopwSpecialist();
    }



    public void updateProfile(){
          AndroidNetworking.post(API.updateProfile)
                  .addBodyParameter("userid", USERID)
                  .addBodyParameter("Drname", ev_drname.getText().toString().trim())
                  .addBodyParameter("RegNo.",Ev_Regno.getText().toString().trim())
                  .addBodyParameter("specialization" ,"1")
                  .build()
                  .getAsJSONObject(new JSONObjectRequestListener() {


                      @Override

                      public void onResponse(JSONObject response) {
                          Log.e("gfdsgdfg", response.toString());
                          Toast.makeText(ProfileSettingActivity.this, "Added SuccessFully", Toast.LENGTH_SHORT).show();
                      }

                      @Override
                      public void onError(ANError anError) {

                      }
                  });




      }


      public void shopwSpecialist(){
        AndroidNetworking.post(API.show_speciality)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {

                        arr_specID=new ArrayList<>();
                        arr_specName=new ArrayList<>();
                        arr_specID.add("0");
                        arr_specName.add("Select speciality");

                        try {
                            for (int i = 0; i <response.length() ; i++) {
                                JSONObject jsonObject=response.getJSONObject(i);
                                arr_specID.add(jsonObject.getString("id"));
                                arr_specName.add(jsonObject.getString("name"));

                            }


                            ArrayAdapter adapter = new ArrayAdapter<String>(getApplicationContext(),
                                    android.R.layout.simple_spinner_item, arr_specName);
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            sp_mbbs.setAdapter(adapter);


                            sp_mbbs.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    String tutorialsName =arr_specName.get(position) ;
                                    Toast.makeText(parent.getContext(), "Selected: " + tutorialsName,      Toast.LENGTH_LONG).show();
                                }
                                @Override
                                public void onNothingSelected(AdapterView <?> parent) {
                                }
                            });
                        }catch (Exception e){

                        }

                    }

                    @Override
                    public void onError(ANError anError) {

                    }
                });

      }
}