package com.maestros.arogyalabside.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.maestros.arogyalabside.ModelClass.ModelShowBooking;
import com.maestros.arogyalabside.R;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ShowBookingAdapter extends RecyclerView.Adapter<ShowBookingAdapter.ViewHolder> {

         ArrayList<ModelShowBooking>ModelShowBookings;
        Context contexts;

        public ShowBookingAdapter(ArrayList<ModelShowBooking>ModelShowBooking, Context contexts) {
            this.ModelShowBookings = ModelShowBooking;
            this.contexts = contexts;
        }


        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
            View listItem=layoutInflater.inflate(R.layout.layout_show_booking,parent,false);
            ViewHolder viewHolder=new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            final ModelShowBooking ModelShowBooking=ModelShowBookings.get(position);

            holder.username1.setText(ModelShowBooking.getShowUserName());
            holder.tv_age1.setText(ModelShowBooking.getShowAge());
            holder.tv_datetime.setText(ModelShowBooking.getShowDatetime());
            holder.Tv_history1.setText(ModelShowBooking.getShowHistory());
            holder.tv_status1.setText(ModelShowBooking.getShowStatus());
            holder.tv_pending.setText(ModelShowBooking.getShowPending());

            Glide.with(contexts).load(ModelShowBooking.getShowPath()+ModelShowBooking.getShowPic()).into(holder.img_docter);


        }

        @Override
        public int getItemCount() {
            return ModelShowBookings.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            public CircleImageView img_docter;
            public TextView username1,tv_age1,tv_datetime,Tv_history1,tv_status1,tv_pending;
            public CardView cardview;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                img_docter=itemView.findViewById(R.id.img_docter);
                username1=itemView.findViewById(R.id.username1);
                tv_age1=itemView.findViewById(R.id.tv_age1);
                tv_datetime=itemView.findViewById(R.id.tv_datetime);
                Tv_history1=itemView.findViewById(R.id.Tv_history1);
                tv_status1=itemView.findViewById(R.id.tv_status1);
                tv_pending=itemView.findViewById(R.id.tv_pending);
                cardview=itemView.findViewById(R.id.cardview);


            }
        }
    }

