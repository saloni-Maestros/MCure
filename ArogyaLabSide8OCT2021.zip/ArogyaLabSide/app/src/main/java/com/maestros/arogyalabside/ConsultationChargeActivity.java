package com.maestros.arogyalabside;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.button.MaterialButton;

public class ConsultationChargeActivity extends AppCompatActivity {
 MaterialButton materialbutton2;
 ImageView imgarrow_charges;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultation_charge);
        materialbutton2 = findViewById(R.id.materialbutton2);
        imgarrow_charges=findViewById(R.id.imgarrow_charges);

        imgarrow_charges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        materialbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ConsultationChargeActivity.this,ConsultationsCharge2Activity.class));
            }
        });
    }
}