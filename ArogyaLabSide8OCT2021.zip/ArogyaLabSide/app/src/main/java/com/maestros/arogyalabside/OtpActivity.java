package com.maestros.arogyalabside;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.material.button.MaterialButton;
import com.maestros.arogyalabside.others.API;
import com.maestros.arogyalabside.others.APPCONSTANT;
import com.maestros.arogyalabside.others.SharedHelper;

import org.json.JSONObject;

public class OtpActivity extends AppCompatActivity {
    MaterialButton materialbuttonlogin;
    String MOBILE = "";
    ProgressBar progressbar;
    EditText Edittext_otp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        MOBILE = SharedHelper.getKey(OtpActivity.this, APPCONSTANT.MOBILE);
        materialbuttonlogin = findViewById(R.id.materialbuttonlogin);
        Edittext_otp = findViewById(R.id.Edittext_otp);
        progressbar = findViewById(R.id.progressbar);
        materialbuttonlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Edittext_otp.getText().toString().trim().isEmpty()) {
                    Toast.makeText(OtpActivity.this, "please Enter Otp", Toast.LENGTH_SHORT).show();
                } else
                    otpVerify();

            }
        });
    }

    public void otpVerify() {
        AndroidNetworking.post(API.otp)
                .addBodyParameter("otp", Edittext_otp.getText().toString().trim())
                .addBodyParameter("mobile", MOBILE)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("OtpActivity", response.toString());
                        try {
                            if (response.getString("result").equals("Login Successful")) {
                                startActivity(new Intent(OtpActivity.this,NavActivity .class));

                            } else {
                                Toast.makeText(OtpActivity.this, "" + response.getString("result"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {

                        }
                    }


                    @Override
                    public void onError(ANError anError) {
                        Log.e("OtpActivity", anError.getMessage());
                    }
                });


    }
}