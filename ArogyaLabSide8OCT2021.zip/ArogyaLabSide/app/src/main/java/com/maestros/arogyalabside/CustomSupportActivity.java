package com.maestros.arogyalabside;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class CustomSupportActivity extends AppCompatActivity {

    ImageView imgarrow_support;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_support);

        imgarrow_support=findViewById(R.id.imgarrow_support);
        imgarrow_support.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}