package com.maestros.arogyalabside.others;

public class APPCONSTANT {
    public static String USERID="USERID";
    public static String MOBILE="MOBILE";
    public static String RESULT="RESULT";
    public static String TYPE="TYPE";
}
