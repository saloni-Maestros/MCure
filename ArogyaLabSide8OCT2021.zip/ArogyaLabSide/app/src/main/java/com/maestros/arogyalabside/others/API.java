package com.maestros.arogyalabside.others;

public class API {

    public static String BASEURL="https://ruparnatechnology.com/arogya/api/process.php?action=";
    public static String signup=BASEURL+"doctor_signup";
    public static String otp= BASEURL+"otp_verfication";
    public static  String updateProfile = BASEURL+ "update_profile";
    public static  String show_speciality = BASEURL+ "show_speciality";
    public static String change_mobile_number=BASEURL+"change_mobile_number";
    public static String show_doctor_booking=BASEURL+"show_doctor_booking";
}
